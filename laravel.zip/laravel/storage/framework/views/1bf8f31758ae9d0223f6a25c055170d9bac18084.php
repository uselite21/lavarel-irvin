
<?php $__env->startSection('title','Laravel Irvin : Ubah Informasi Mahasiswa'); ?>

<?php $__env->startSection('container'); ?>
<div class="container mt-5">
	<div class="" style="min-height: 85vh">
		<div class="">
			<h6 class="display-3 text-info"><span style="color: white;"><B>LARAVEL IRVIN</B></h6>
			<h2 class="text-info"><span style="color: grey;">Perbaharui Informasi Mahasiswa</h2>
			
		</div>
		<div class="col-md-7"><hr>
			<div class="card mb-5">
				<div class="card-body  ">
					<form action="http://localhost/laravel/public/mahasiswa/<?php echo e($student->id); ?>" method="post">
						<?php echo method_field('patch'); ?>
						<?php echo csrf_field(); ?>
					  <div class="form-row">
					    <div class="form-group col-md-7">
					      <label for="nama">Nama Lengkap</label>
					      <input type="text" class="form-control" id="nama" name="nama" value="<?php echo e($student->nama); ?>">
					    </div>
					    <div class="form-group col-md-5">
					      <label for="nim">No. Induk Mahasiswa</label>
					      <input type="text" class="form-control" id="nim" name="nim" value="<?php echo e($student->nim); ?>">
					    </div>
					  </div>
					  <div class="form-row">
					    <div class="form-group col-md-6">
					      <label for="email">>Email</label>
					      <input type="email" class="form-control" id="email" name="email" value="<?php echo e($student->email); ?>">
					    </div>
					    <div class="form-group col-md-6">
					      <label for="prodi">Program Studi</label>
					      <input type="text" class="form-control" id="prodi" name="prodi" value="<?php echo e($student->prodi); ?>">
					    </div>
					  </div>
					  <div class="form-row">
					    <div class="form-group col-md-5">
					      <label for="fakultas">Fakultas</label>
					      <input type="text" class="form-control" id="fakultas" name="fakultas" value="<?php echo e($student->fakultas); ?>">
					    </div>
					    <div class="form-group col-md-7">
					      <label for="universitas">Universitas</label>
					      <input type="text" class="form-control" id="universitas" name="universitas" value="<?php echo e($student->universitas); ?>">
					    </div>
					  </div>
					  
					
				</div>
				<div class="card-footer">
					<div class="d-flex justify-content-between align-items-center">
						<div>
							<a href="http://localhost/laravel/public/mahasiswa/<?php echo e($student->id); ?>" class="btn btn-sm btn-secondary" style="border-radius: 15px"><i class="fas fa-chevron-left fa-fw" ></i> Kembali</a>
						</div>
						<div>
							<button type="submit" class="btn btn-sm btn-info" style="border-radius: 15px"> <i class="fas fa-sync"></i> Simpan Perubahan</button>
						</div>
					</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp2\htdocs\laravel\resources\views/students/edit.blade.php ENDPATH**/ ?>