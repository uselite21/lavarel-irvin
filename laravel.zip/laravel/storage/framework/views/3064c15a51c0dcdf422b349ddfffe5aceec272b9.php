
<?php $__env->startSection('title','Z-App : Mahasiswa'); ?>

<?php $__env->startSection('container'); ?>
<div class="container mt-5">
	<div class="" style="min-height: 85vh">
		<div class="col-md-5">
			<h6 class="display-3 text-info">Z-App</h6>
			<h2 class="text-info">The Ultimate Students Data Management</h2>
			<hr>
			Built with Laravel v8.5.16
			<!-- <br><br><br><br><br><br><br><br><br><br><br><br> -->
		</div>
		<div class="col-md-7 mx-0 px-1">
				<div class="card-body mx-0 px-0"><hr class="mx-2">
					<table class="table table-borderless ">
					  <thead>
					    <tr>
					      <th scope="col">No.</th>
					      <th scope="col">Nama lengkap</th>
					      <th scope="col" class="text-right"><a href="http://localhost:8000/mahasiswa/tambah" class="btn btn-sm btn-success" style="border-radius: 15px"><i class="fas fa-plus fa-fw"></i> Tambah Mahasiswa </a></th>
					    </tr>
					  </thead>
					  <tbody>
					  	<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					    <tr>
					      <th scope="row"><?php echo e($key+1); ?></th>
					      <td><?php echo e($student->nama); ?></td>
					      <td class="text-right"><a href="http://localhost:8000/mahasiswa/<?php echo e($student->id); ?>" class="btn btn-sm btn-primary" style="border-radius: 15px">Detail <i class="fas fa-info-circle fa-fw"></i></a></td>
					    </tr>
					    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					  </tbody>
					</table>
				</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Z-App\resources\views/students/index.blade.php ENDPATH**/ ?>