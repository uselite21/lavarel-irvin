
<?php $__env->startSection('title','Laravel Irvin : Informasi Mahasiswa'); ?>

<?php $__env->startSection('container'); ?>
<div class="container mt-5 align-content-center">
	<div class="" style="min-height: 85vh">
		<div class="">
			<h6 class="display-3 text-info"><span style="color: white;"><B>LARAVEL IRVIN</B></h6>
			<h2 class="text-info"><span style="color: grey;">Informasi Mahasiswa</h2>
			
		</div>
		<div class="col-md-7 mx-0 px-0">
			<div class="card-body "><hr class="">
				<h5 class="card-title"><span style="color: white;"><?php echo e($student->nama); ?></h5>
			    <h6 class="card-subtitle mb-2 text-muted"><?php echo e($student->email); ?></h6><br>
			    <dl class="row">
				  <dt class="col-sm-3"><span style="color: white;">NIM</dt>
				  <dd class="col-sm-9"><span style="color: white;"><?php echo e($student->nim); ?></dd>

				  <dt class="col-sm-3"><span style="color: white;">Program Studi</dt>
				  <dd class="col-sm-9"><span style="color: white;"><?php echo e($student->prodi); ?></dd>

				  <dt class="col-sm-3"><span style="color: white;">Fakultas</dt>
				  <dd class="col-sm-9"><span style="color: white;"><?php echo e($student->fakultas); ?></dd>

				  <dt class="col-sm-3"><span style="color: white;">Universitas</dt>
				  <dd class="col-sm-9"><span style="color: white;"><?php echo e($student->universitas); ?></dd>
				 </dl><hr>
				 <a href="http://127.0.0.1/laravel/public/" class="btn btn-secondary mr-5 btn-sm" style="border-radius: 15px"><i class="fas fa-chevron-left"></i> Back</a>
				 <a href="http://127.0.0.1/laravel/public/mahasiswa/<?php echo e($student->id); ?>/edit" class="btn btn-warning ml-5 btn-sm" style="border-radius: 15px" ><i class="fas fa-edit" ></i><span style="color: white;"> Edit</a>
				 <form class="d-inline" action="http://localhost/laravel/public/mahasiswa/<?php echo e($student->id); ?>" method="post">
					<?php echo method_field('delete'); ?>
                    <?php echo csrf_field(); ?>
					<button class="btn btn-danger btn-sm" style="border-radius: 15px"><i class="fas fa-trash" ></i> Delete</button>
				 </form>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp2\htdocs\laravel\resources\views/students/show.blade.php ENDPATH**/ ?>