
<?php $__env->startSection('title','Z-App : Informasi Mahasiswa'); ?>

<?php $__env->startSection('container'); ?>
<div class="container mt-5">
	<div class="" style="min-height: 85vh">
		<div class="col-md-5">
			<h6 class="display-3 text-info">Z-App</h6>
			<h2 class="text-info">Student's Information</h2>
			
		</div>
		<div class="col-md-7 mx-0 px-0">
			<div class="card-body "><hr class="">
				<h5 class="card-title"><?php echo e($student->nama); ?></h5>
			    <h6 class="card-subtitle mb-2 text-muted"><?php echo e($student->email); ?></h6><br>
			    <dl class="row">
				  <dt class="col-sm-3">NIM</dt>
				  <dd class="col-sm-9"><?php echo e($student->nim); ?></dd>

				  <dt class="col-sm-3">Program Studi</dt>
				  <dd class="col-sm-9"><?php echo e($student->prodi); ?></dd>

				  <dt class="col-sm-3">Fakultas</dt>
				  <dd class="col-sm-9"><?php echo e($student->fakultas); ?></dd>

				  <dt class="col-sm-3">Universitas</dt>
				  <dd class="col-sm-9"><?php echo e($student->universitas); ?></dd>
				 </dl><hr>
				 <a href="http://localhost:8000/" class="btn btn-secondary mr-5 btn-sm" style="border-radius: 15px"><i class="fas fa-chevron-left"></i> Back</a>
				 <a href="http://localhost:8000/mahasiswa/<?php echo e($student->id); ?>/edit" class="btn btn-warning ml-5 btn-sm" style="border-radius: 15px" ><i class="fas fa-edit" ></i> Edit</a>
				 <form class="d-inline" action="http://localhost:8000/mahasiswa/<?php echo e($student->id); ?>" method="post">
					<?php echo method_field('delete'); ?>
                    <?php echo csrf_field(); ?>
					<button class="btn btn-danger btn-sm" style="border-radius: 15px"><i class="fas fa-trash" ></i> Delete</button>
				 </form>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Z-App\resources\views/students/show.blade.php ENDPATH**/ ?>