@extends('layout.base')
@section('title','Laravel Irvin : Mahasiswa')

@section('container')
<div class="container mt-5 align-content-center">
	<div class="" style="min-height: 85vh">
		<div class="">
			<h6 class="display-3 text-info"><span style="color: white;"><B>LARAVEL IRVIN</B></h6>
			<h2 class="text-info"><span style="color: grey;">Laravel Powered Students Data Management</h2></span>
			<hr>
			<span style="color: white;">Built with Laravel v8.5.16
			<!-- <br><br><br><br><br><br><br><br><br><br><br><br> -->
		</div>
		<div class="col-md-7 mx-0 px-1">
				<div class="card-body mx-0 px-0"><hr class="mx-2">
					<table class="table table-borderless ">
					  <thead>
					    <tr>
					      <th scope="col"><span style="color: white;">No.</th>
					      <th scope="col"><span style="color: white;">Nama lengkap</th>
					      <th scope="col" class="text-right"><a href="http://localhost/laravel/public/mahasiswa/tambah" class="btn btn-sm btn-success" style="border-radius: 15px"><i class="fas fa-plus fa-fw"></i><span style="color: white;"> Tambah Mahasiswa </a></th>
					    </tr>
					  </thead>
					  <tbody>
					  	@foreach ($students as $key => $student)
					    <tr>
					      <th scope="row"><span style="color: white;">{{$key+1}}</th>
					      <td><span style="color: white;">{{$student->nama}}</td>
					      <td class="text-right"><a href="http://localhost/laravel/public/mahasiswa/{{$student->id}}" class="btn btn-sm btn-primary" style="border-radius: 15px">Detail <i class="fas fa-info-circle fa-fw"></i></a></td>
					    </tr>
					    @endforeach
					  </tbody>
					</table>
				</div>
		</div>
	</div>
</div>
@endsection