@extends('layout.base')
@section('title','Laravel Irvin : Informasi Mahasiswa')

@section('container')
<div class="container mt-5 align-content-center">
	<div class="" style="min-height: 85vh">
		<div class="">
			<h6 class="display-3 text-info"><span style="color: white;"><B>LARAVEL IRVIN</B></h6>
			<h2 class="text-info"><span style="color: grey;">Informasi Mahasiswa</h2>
			
		</div>
		<div class="col-md-7 mx-0 px-0">
			<div class="card-body "><hr class="">
				<h5 class="card-title"><span style="color: white;">{{$student->nama}}</h5>
			    <h6 class="card-subtitle mb-2 text-muted">{{$student->email}}</h6><br>
			    <dl class="row">
				  <dt class="col-sm-3"><span style="color: white;">NIM</dt>
				  <dd class="col-sm-9"><span style="color: white;">{{$student->nim}}</dd>

				  <dt class="col-sm-3"><span style="color: white;">Program Studi</dt>
				  <dd class="col-sm-9"><span style="color: white;">{{$student->prodi}}</dd>

				  <dt class="col-sm-3"><span style="color: white;">Fakultas</dt>
				  <dd class="col-sm-9"><span style="color: white;">{{$student->fakultas}}</dd>

				  <dt class="col-sm-3"><span style="color: white;">Universitas</dt>
				  <dd class="col-sm-9"><span style="color: white;">{{$student->universitas}}</dd>
				 </dl><hr>
				 <a href="http://127.0.0.1/laravel/public/" class="btn btn-secondary mr-5 btn-sm" style="border-radius: 15px"><i class="fas fa-chevron-left"></i> Back</a>
				 <a href="http://127.0.0.1/laravel/public/mahasiswa/{{$student->id}}/edit" class="btn btn-warning ml-5 btn-sm" style="border-radius: 15px" ><i class="fas fa-edit" ></i><span style="color: white;"> Edit</a>
				 <form class="d-inline" action="http://localhost/laravel/public/mahasiswa/{{$student->id}}" method="post">
					@method('delete')
                    @csrf
					<button class="btn btn-danger btn-sm" style="border-radius: 15px"><i class="fas fa-trash" ></i> Delete</button>
				 </form>
			</div>
		</div>
	</div>
</div>
@endsection